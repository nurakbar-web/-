    package com.company;

public interface Printable {
    String print();
}
