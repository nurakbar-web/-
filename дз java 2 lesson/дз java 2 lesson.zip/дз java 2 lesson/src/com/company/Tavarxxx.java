package com.company;

public enum Tavarxxx {
    ХЛЕБ,
    МАЛОКО,
    МАКАРОНЫ,
}
