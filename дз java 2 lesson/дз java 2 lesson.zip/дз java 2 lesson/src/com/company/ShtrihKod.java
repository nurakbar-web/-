package com.company;

public class ShtrihKod {
    private int shtrihKod;

    public ShtrihKod(int shtrihKod) {
        this.shtrihKod = shtrihKod;
    }

    public int getShtrihKod() {
        return shtrihKod;
    }
}
