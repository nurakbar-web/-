package com.company;

public final class Magaz extends Tavar {
    public Magaz(String name, String addres, ShtrihKod shtrihKod, Tavarxxx tavarxxx, int data) {
        super(name, addres, shtrihKod, tavarxxx, data);

    }

    public void pi(String nemogupredumat, int num1){

    }

}

