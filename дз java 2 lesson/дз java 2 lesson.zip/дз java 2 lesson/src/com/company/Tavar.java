package com.company;

public class Tavar extends Firma {
    private int data;

    public Tavar(String name, String addres, ShtrihKod shtrihKod, Tavarxxx tavarxxx, int data) {
        super(name, addres, shtrihKod, tavarxxx);
        this.data = data;
    }

    public int getData() {
        return data;
    }

    public final void pi(int num1){


    }
    public void pi(String nemogupredumat, int num1){

    }
}



